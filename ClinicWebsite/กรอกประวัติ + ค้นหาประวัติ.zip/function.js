function searchID(){
	
    const iframe = document.getElementById("animalH");
    const iWindow = iframe.contentWindow;
    const iDocument = iWindow.document;
    console.log("asdd")

    let x = document.getElementById("idA").value;
	if (x === "123"){
        iDocument.getElementById("nameP").innerHTML = "นายยินดี ไม่มีปัญหา";
        iDocument.getElementById("idP").innerHTML = "1809901060222";
        iDocument.getElementById("address").innerHTML = "1/12 ถนนคนเดิน อำเภอเมืองปทุมธานี จังหวัดปทุมธานี 80000";
        iDocument.getElementById("phone").innerHTML = "0986957878";
        iDocument.getElementById("nameA").innerHTML = "ไข่ต้ม";
        iDocument.getElementById("type").innerHTML = "แมว";
        iDocument.getElementById("bDate").innerHTML = "1/10/2564";
        iDocument.getElementById("age").innerHTML = "1";
        iDocument.getElementById("date1").innerHTML = "1/04/2565";
        iDocument.getElementById("treat1").innerHTML = "ฉีดวัคซีนพิษสุนัขบ้า";
	}
    else{
        iDocument.getElementById("nameP").innerHTML = "-";
        iDocument.getElementById("idP").innerHTML = "-";
        iDocument.getElementById("address").innerHTML = "-";
        iDocument.getElementById("phone").innerHTML = "-";
        iDocument.getElementById("nameA").innerHTML = "-";
        iDocument.getElementById("type").innerHTML = "-";
        iDocument.getElementById("bDate").innerHTML = "-";
        iDocument.getElementById("age").innerHTML = "-";
        iDocument.getElementById("date1").innerHTML = "-";
        iDocument.getElementById("treat1").innerHTML = "-";
    }
	
}